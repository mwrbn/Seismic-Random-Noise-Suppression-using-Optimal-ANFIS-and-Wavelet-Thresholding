
# Seismic OANFIS WT Project

## Run
pip install -r requirements.txt
python main.py

## Description
Hybrid seismic denoising using ANFIS + Wavelet Thresholding
