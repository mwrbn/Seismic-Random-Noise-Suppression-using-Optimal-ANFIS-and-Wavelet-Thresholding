
import numpy as np

def ricker_wavelet(t, f, t0):
    return (1 - 2*(np.pi**2)*(f**2)*(t-t0)**2) * np.exp(-(np.pi**2)*(f**2)*(t-t0)**2)

def add_noise(signal, sigma=0.1):
    return signal + np.random.normal(0, sigma, len(signal))
