
import numpy as np
import matplotlib.pyplot as plt
from signal_generation import ricker_wavelet, add_noise

t = np.linspace(0, 1, 1000)
signal = ricker_wavelet(t, 15, 0.4) + ricker_wavelet(t, 20, 0.8)
noisy = add_noise(signal, 0.2)

plt.plot(t, signal, label="Clean")
plt.plot(t, noisy, label="Noisy")
plt.legend()
plt.show()
