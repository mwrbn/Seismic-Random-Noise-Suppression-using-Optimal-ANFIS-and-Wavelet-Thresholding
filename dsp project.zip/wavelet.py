
import numpy as np

def wavelet_threshold(w, lam):
    w = np.array(w)
    out = np.zeros_like(w)
    for i in range(len(w)):
        if abs(w[i]) > lam:
            out[i] = np.sign(w[i]) * (abs(w[i]) - lam)
        else:
            out[i] = 0
    return out
